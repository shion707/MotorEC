clear; close all
load('Exp_4')

%%
% fit systematic bias
shandall=[];
% figure
for  s=1:subnum
    hand=hand_common_bin_angle(:,s);
    f=find(hand>-1000);
    p = polyfit(target_angle(f,s),hand(f),20);

    x1 = 1:1:360;
    y1 = polyval(p,x1);

    % subplot(6,7,s)
    % hold on


    kk=0;
    for y=1:360
        kk=kk+1;
        f=find(target_angle(:,s)==y);
        h=hand(f);
        h=removeoutlier(h,2.5);
        bias(kk)=nanmean(h);
    end
    % 
    % plot(1:360,bias,'k.')
    % 
    % plot(x1,y1,'r-','LineWidth',3)

    %axis([0 360 -8 8])
    % ax = gca;
    % ax.YAxis.TickDirection = 'out';
    % ax.XAxis.TickDirection = 'out';


    shand=[];
    for i=1:length(mt_bin)
        ta=target_angle(i,s);
        if ta>360
            ta=ta-360;
        end
        shand=[shand y1(ta)];
    end

    shandall(:,s)=shand;
end

%%
% bias based on outward reaching
figure
hand=hand_common_bin_angle-shandall;
% hand(f)=NaN;
hand=removeoutlier(hand,2.5);
movar=nanstd(hand);
nanmean(movar)

diffangle_o=target_angle(1:end-1,:)-target_angle(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
%diffangle=abs(diffangle_o);
diffangle_index=round(diffangle/30)+7;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
allt=[];
for subj=1:subnum

    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        if (y<7 && y>4)
            allt=[allt;h];
        elseif(y<10 && y>7)
            allt=[allt;-h];
        end
        h=removeoutlier(h,2.5);
        sdm(subj,y)=nanmean(h);

        sdm_v(subj,y)=nanstd(h);
    end
    %skew_value(subj) = skewness(allt)
end
sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm(:));
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])


dif=nanmean(sdm(:,5:6),2)-nanmean(sdm(:,8:9),2);
dif=removeoutlier(dif,2.5);
difo=dif;


subplot(2,2,3);hold on
realboxplot(1,dif,[0 0 0],0.3,0.4);
plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1);
lineerrorbar('x',1, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);
scatter(1,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20);

set(gca,'xtick',[]);
axis([-1 6 -1.5 4.9])

[a b c d]=ttest(dif);
cohensD = (nanmean(dif)) / nanstd(dif)

%fun = @(p,x)p(1).*p(2).*sind(x).*exp(p(2).*cosd(x));

subplot(2,2,4);hold on
err=nanstd(hand);
scatter(err(err>0),dif(err>0),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
coefficients = polyfit(err(err>0)',dif(err>0), 1);
fittedY = polyval(coefficients, err(err>0));
plot(err(err>0),fittedY)
[a,b]=corr(dif(err>0),err(err>0)')
axis([3.1 10.9 -1.5 4.9])

ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';


co=[0.7 0 0];

subplot(2,2,2);hold on
plot([7 7],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
plot(nanmean(sdm),'LineWidth',1,'color',co)


set(gca,'xtick',[1:3:20]);
axis([0 14 -2.5 2.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
%set(gca, 'LineWidth',1);
% p=[2,5];
% 
% f=find(hand>-10000);
% cc=sqrt(2)/exp(-0.5);
% fun = @(p,x)von_mises_derivative(x, 0, p(1))*p(2); 
% beta1 = lsqcurvefit(fun,p,diffangle(f)/180*pi,hand(f),[-inf;-inf],[inf;inf]);
% 
% subplot(2,2,2); hold on
% p=beta1;
% x=unique(diffangle(f));
% plot((x/30)+7,von_mises_derivative(x/180*pi, 0, p(1))*p(2),'-','LineWidth',3,'color',co)
% 



%%
% variance based on outward reaching

for backs=[1]
    figure

    hand=hand_common_bin_angle-shandall;
    hand=removeoutlier(hand,2.5);

    diffangle_o=hand_angle(3:end-backs-2,:)-hand_angle(backs+1+2:end-2,:);
    f=find((diffangle_o)>180);
    diffangle_o(f)=(diffangle_o(f)-360);
    f=find((diffangle_o)<-180);
    diffangle_o(f)=(diffangle_o(f)+360);

    diffangle=abs(diffangle_o);
    diffangle_index=ceil(diffangle/30);
    m=max(max(diffangle_index));
    sd=[];
    s=sign(diffangle_o);
    hand=s.*hand(backs+1+2:end-2,:);
    sdm=[];
    sdm_v=[];
    allt=[];
    for subj=1:subnum
        for y=1:m
            sd(subj).y(y).l=[0];
        end
    end

    for subj=1:subnum
        for y=1:m
            f=find(diffangle_index(:,subj)==y);
            sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
            h=hand(f,subj);
            sdm(subj,y)=nanmean(h);
            sdm_v(subj,y)=nanstd(h);
            if (y<8)&& (y>0)
                allt=[allt;-h];
            end
        end
        allt=removeoutlier(allt,3);
        skew_value(subj) = skewness(allt);
        allt=[];
    end

    sdm_v(:,end)=[];
    sdm_v=removeoutlier(sdm_v,3);
    sdm_v=sdm_v./nanmean(sdm_v')';


    sdm_v(sdm_v<0.001)=nan;


    subplot(2,2,3);hold on
    plot(sdm_v')
    plot(nanmean(sdm_v),'LineWidth',5);
    figure
    %sdm_v=sdm_v(:,2:end);
    subplot(2,3,1);hold on
    se=[nanstd(sdm_v)./sqrt(subnum)];
    averag=nanmean(sdm_v)';
    for i=1:size(sdm_v,2)
        %fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2)
        %plot(nanmean(sdm_v),'LineWidth',3);
        lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
        scatter(i,averag(i),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',60)
    end
    axis([0 6 0.92 1.07])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';


        initial_params = [1, 1, 1];

        % Create a fit type object
        ft = fittype('a + (b-a) / (1 + exp(-c * (x)))', ...
            'independent', 'x', ...
            'coefficients', {'a', 'b', 'c'});
    
    y=sdm_v';
    x=repmat(1:5,1,subnum)';
    y=y(:);
    % Bootstrap resampling
    num_bootstrap_samples = 100;
    bootstrap_ab = zeros(num_bootstrap_samples, 1);
    rng(0); % For reproducibility

    for i = 1:num_bootstrap_samples
        % Resample the data with replacement
        idx = randi(length(x), length(x), true);
        x_resample = x(idx);
        y_resample = y(idx);

        % Fit the model to the resampled data
        [fitresult, ~] = fit(x_resample, y_resample, ft, 'StartPoint', initial_params);

        % Compute the product a * b for the resampled fit
        bootstrap_ab(i) = (fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));
    end


    if backs==-1
        backs=0;
    end
    subplot(2,2,2);hold on
    %bar(backs,nanmean(bootstrap_ab));
    %     alpha = 0.05; % 95% confidence interval
    %bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
    %     bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
    %     ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
    %     lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',ci_ab(2)-ci_ab(1),'width', 1.5)
    %     realboxplot(backs,bootstrap_ab',[0 0 0],0.3,0.4)
    bar(backs,nanmean(bootstrap_ab));
    alpha = 0.001; % 95% confidence interval
    ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
    lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',nanstd(bootstrap_ab),'width', 1.5)
    %realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';
    axis([-1 6 -0.03 0.09])

end








%%
%bias based on return movement

rotationf=rotation;

k=rotationf<180;
m=rotationf>=180;

rotationf(k)=rotationf(k)+180;
rotationf(m)=rotationf(m)-180;

hand=hand_common_bin_angle-shandall;
hand=removeoutlier(hand,2.5);
movar=nanstd(hand);
nanmean(movar)


diffangle_o=rotationf(1:end-1,:)-target_angle(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
%diffangle=abs(diffangle_o);
diffangle_index=round(diffangle/30)+7;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
allt=[];
for subj=1:subnum

    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        sdm(subj,y)=nanmean(h);

        sdm_v(subj,y)=nanstd(h);
    end
    %skew_value(subj) = skewness(allt)
end
sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm(:));
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])


dif=nanmean(sdm(:,4:6),2)-nanmean(sdm(:,8:10),2);
%dif=removeoutlier(dif,2.5);
difr=dif;
[a b c d]=ttest(dif);
cohensD = (nanmean(dif)) / nanstd(dif)

[a b c d]=ttest(difr-difo)
cohensD = (nanmean(difr-difo)) / nanstd(difr-difo)

figure
subplot(2,2,3);hold on
realboxplot(backs,dif,[0 0 0],0.3,0.4);
plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',backs);
lineerrorbar('x',backs, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);
scatter(backs,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20);

set(gca,'xtick',[]);
axis([-1 6 -1.5 4.9])

[a b c]=ttest(dif);

%fun = @(p,x)p(1).*p(2).*sind(x).*exp(p(2).*cosd(x));

% subplot(2,2,4);hold on
% err=nanstd(hand);
% scatter(err(err>0),dif(err>0),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
% coefficients = polyfit(err(err>0)',dif(err>0), 1);
% fittedY = polyval(coefficients, err(err>0));
% plot(err(err>0),fittedY)
% [a,b]=corr(dif(err<12),err(err<12)')
% axis([3.1 7.9 -1.5 4.9])
% 
% ax = gca;
% ax.YAxis.TickDirection = 'out';
% ax.XAxis.TickDirection = 'out';


co=[0.7 0 0];

subplot(2,2,2);hold on
plot([7 7],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
plot(nanmean(sdm),'LineWidth',1,'color',co)


set(gca,'xtick',[1:3:20]);
axis([0 14 -2.5 2.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
%set(gca, 'LineWidth',1);

% 
% p=[2,5];
% 
% f=find(hand>-10000);
% cc=sqrt(2)/exp(-0.5);
% fun = @(p,x)von_mises_derivative(x, 0, p(1))*p(2); 
% beta1 = lsqcurvefit(fun,p,diffangle(f)/180*pi,hand(f),[-inf;-inf],[inf;inf]);
% 
% subplot(2,2,2); hold on
% p=beta1;
% x=unique(diffangle(f));
% plot((x/30)+7,von_mises_derivative(x/180*pi, 0, p(1))*p(2),'-','LineWidth',3,'color',co)
% 
%%
%variance based on return movement

for backs=[1]

    hand=hand_common_bin_angle-shandall;

    f=find(abs(hand)>40);%%%%%%
    hand_angle(f)=NaN;
    hand=removeoutlier(hand,2.5);

    diffangle_o=rotationf(1:end-backs-2,:)-hand_angle(backs+1:end-2,:);
    f=find((diffangle_o)>180);
    diffangle_o(f)=(diffangle_o(f)-360);
    f=find((diffangle_o)<-180);
    diffangle_o(f)=(diffangle_o(f)+360);

    diffangle=abs(diffangle_o);
    diffangle_index=ceil(diffangle/30);
    m=max(max(diffangle_index));
    sd=[];
    s=sign(diffangle_o);
    hand=s.*hand(backs+1:end-2,:);
    sdm=[];
    sdm_v=[];
    allt=[];
    for subj=1:subnum
        for y=1:m
            sd(subj).y(y).l=[0];
        end
    end

    for subj=1:subnum
        for y=1:m
            f=find(diffangle_index(:,subj)==y);
            sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
            h=hand(f,subj);
            %h=removeoutlier(h,2.5);
            sdm(subj,y)=nanmean(h);
            sdm_v(subj,y)=nanstd(h);
        end
    end
    sdm=removeoutlier(sdm,2.5);

    sdm_v(:,end)=[];
    sdm_v=sdm_v./nanmean(sdm_v')';

    figure
    %sdm_v=sdm_v(:,2:end);
    subplot(2,3,1);hold on
    se=[nanstd(sdm_v)./sqrt(subnum)];
    averag=nanmean(sdm_v)';
    for i=1:size(sdm_v,2)
        %fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2)
        %plot(nanmean(sdm_v),'LineWidth',3);
        lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
        scatter(i,averag(i),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',60)
    end
    axis([0 6 0.92 1.07])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';

    for s=1:subnum

        l(s)=corr([1:5]',sdm_v(s,:)');
        % Initial guesses for the parameters [a, b, c, d]
        initial_params = [1, 1, 1];

        % Create a fit type object
        ft = fittype('a + (b-a) / (1 + exp(-c * (x)))', ...
            'independent', 'x', ...
            'coefficients', {'a', 'b', 'c'});
        % Fit the data


        [fitresult, gof] = fit([1:5]', sdm_v(s,:)', ft, 'StartPoint', initial_params);
        l(s)=(fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));

    end
    y=sdm_v';
    x=repmat(1:5,1,subnum)';
    y=y(:);
    % Bootstrap resampling
    num_bootstrap_samples = 100;
    bootstrap_ab = zeros(num_bootstrap_samples, 1);
    rng(0); % For reproducibility

    for i = 1:num_bootstrap_samples
        % Resample the data with replacement
        idx = randi(length(x), length(x), true);
        x_resample = x(idx);
        y_resample = y(idx);

        % Fit the model to the resampled data
        [fitresult, ~] = fit(x_resample, y_resample, ft, 'StartPoint', initial_params);

        % Compute the product a * b for the resampled fit
        bootstrap_ab(i) = (fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));
    end


    if backs==-1
        backs=0;
    end
    subplot(2,2,2);hold on
    bar(backs,nanmean(bootstrap_ab));
    alpha = 0.05; % 95% confidence interval
    ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
    lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',nanstd(bootstrap_ab),'width', 1.5)
    %realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';
    axis([-1 6 -0.03 0.09])
end

