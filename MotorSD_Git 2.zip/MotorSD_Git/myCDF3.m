% Define your custom CDF function
% Here is a uniform + Normal 

function p = myCDF3(x,x0)

p=x0(1)*unifcdf(x,-200,200)+normcdf((x),0,x0(2));

end