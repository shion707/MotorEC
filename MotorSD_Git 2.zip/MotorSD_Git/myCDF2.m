% Define your custom CDF function
% Here is a uniform + Normal 

function p = myCDF2(x)

p=7*unifcdf(x,-360,360)+1*normcdf((x),0,50);

end