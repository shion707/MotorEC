function LL=EC(data1,diffangle,varl,x0)


for v0=1:180
       vtld = myCDF3(v0,x0(1:2))+0.01;
       guess = v0;
       vhat= [fzero(@(x) myCDF3(x,x0(1:2)) - vtld, guess)];
       % (F-1)'
       Fp(v0)=vhat-v0;
       vtld = myCDF3(v0,x0(1:2))+0.02;
       guess = v0;
       vhat2= [fzero(@(x) myCDF3(x,x0(1:2)) - vtld, guess)];
       % (F-1)''
       Fpp(v0)=2*vhat-v0-vhat2;
end


varr=Fp./mean(Fp);
varr=varr(30:30:150);
bias=x0(3)*[-Fpp(end:-1:1) 0 Fpp];
hindx=round(diffangle)+181;
simdata=bias(hindx);
LL=nanmean(nanmean((data1-bias(hindx)).^2))+nanmean((varl'-varr).^2);
