load('Exp1corr.mat');
diff1=dif(err>0);
err1=err(err>0);

load('Exp3corr.mat');
diff3=dif(err>0);
err3=err(err>0);

load('Exp5corr.mat');
diff5=dif(err>0);
err5=err(err>0);

err=[err1 err3 err5];
dif=[diff1' diff3' diff5'];
%%
figure
subplot(2,2,4);hold on

scatter(err(err>0),dif(err>0),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
coefficients = polyfit(err(err>0)',dif(err>0), 1);
fittedY = polyval(coefficients, err(err>0));
plot(err(err>0),fittedY)
[a,b]=corr(dif(err>0)',err(err>0)');

axis([3.1 8.1 -1.5 4.9])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';


%%
figure
for i=1:2000
    boot=randi(91,36,1);
    dif_b=dif(boot)+(randn(1,36))*1.3;
    err_b=err(boot)+abs(randn(1,36))*1.3;

    % subplot(2,2,4);hold on
    % scatter(err_b,dif_b,'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
    % coefficients = polyfit(err_b,dif_b, 1);
    % fittedY = polyval(coefficients, err_b);
    % plot(err_b,fittedY)
    %     axis([3.1 8.1 -1.5 4.9])
    % ax = gca;
    % ax.YAxis.TickDirection = 'out';
    % ax.XAxis.TickDirection = 'out';
    [a,b]=corr(dif_b',err_b');

    rlist(i)=a;
    plist(i)=(1-b)*sign(a);

end

figure;
subplot(2,2,1)
hist(rlist,50) 
subplot(2,2,2)
hist(plist,100) 

sum(rlist<0.07)/1000;
sum(rlist<0.24)/1000;


sum(plist<0.26)/1000;
sum(plist<0.80)/1000;