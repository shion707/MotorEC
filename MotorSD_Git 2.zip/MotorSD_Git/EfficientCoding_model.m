clear;close all
% simulation of a effiecent coding model

% caculating the prim and the second order prim 
% of the reverse function of the custermized prior CDF function (myCDF2)

for v0=1:180
       vtld = myCDF2(v0)+0.01;
       guess = v0;
       vhat= [fzero(@(x) myCDF2(x) - vtld, guess)];
       % (F-1)'
       Fp(v0)=vhat-v0;
       vtld = myCDF2(v0)+0.02;
       guess = v0;
       vhat2= [fzero(@(x) myCDF2(x) - vtld, guess)];
       % (F-1)''
       Fpp(v0)=2*vhat-v0-vhat2;
end


figure

subplot(2,2,1);hold on
x=1:180;
v=Fp*10;
plot(x,v./mean(v));
title('variance')

subplot(2,2,2);hold on
bias=[-Fpp(end:-1:1) 0 Fpp]*100;
x=[-180:180];
plot(x,bias);
title('bias')