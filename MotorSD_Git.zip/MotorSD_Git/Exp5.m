clear;close all
load('SD_ip_all','dataall')

subnum=25;
numTrials=2160;

handEndAngle=squeeze(dataall(:,1,:));
mt=squeeze(dataall(:,2,:));
rt=squeeze(dataall(:,3,:));
rotation=squeeze(dataall(:,4,:));
target_angle=squeeze(dataall(:,9,:));
Left_right=squeeze(dataall(:,5,:));


f=find(handEndAngle<-180);
handEndAngle(f)=handEndAngle(f)+360;
f=find(handEndAngle<-180);
handEndAngle(f)=handEndAngle(f)+360;
f=find(handEndAngle>180);
handEndAngle(f)=handEndAngle(f)-360;
f=find(handEndAngle>180);
handEndAngle(f)=handEndAngle(f)-360;

hand_angle=handEndAngle+target_angle;
hand_angle(hand_angle>360)=hand_angle(hand_angle>360)-360;
hand_angle(hand_angle>360)=hand_angle(hand_angle>360)-360;
hand_angle(hand_angle<0)=hand_angle(hand_angle<0)+360;


target_anglerow=target_angle;

handEndAngle(handEndAngle>50)=nan;
handEndAngle=removeoutlier(handEndAngle,2.5);

mmt=nanmedian(mt);
color=[0,0,0];
handEndAngle(:,[12])=nan;
handEndAngle=removeoutlier(handEndAngle,3);
%%

figure; hold on

plot((handEndAngle(:,:)),'-','linewidth',1)
plot((rotation(:,1)),'k','linewidth',1)

%%
%LEFT HAND
%systematic bias
hand=handEndAngle;

for s=1:subnum
    f=find(handEndAngle(:,s)>-1000 & target_angle(:,s)<360);
    p = polyfit(target_angle(f,s),handEndAngle(f,s),15);

    x1 = 1:1:360;
    y1 = polyval(p,x1);
    figure(332); subplot(6,6,s)
    %plot(target_angle,hand_common_bin_angle,'o')
    hold on

    bias=[];
    kk=0;

    for y=1:1:360
        kk=kk+1;
        f=find(target_angle(:,s)==y);
        %mean.y(y).l=[mean.y(y).l; hand(f)];
        h=hand(f,s);
        h=removeoutlier(h,2.5);
        bias(kk)=nanmean(h);
    end

    plot(x1(1:1:end),bias,'k.')
    plot(x1,y1,'r-')


    %RIGHT HAND
    f=find(handEndAngle(:,s)>-1000 & target_angle(:,s)>360);
    p = polyfit(target_angle(f,s),handEndAngle(f,s),15);
    x2 = 361:1:720;
    y2 = polyval(p,x2);
    figure(333); subplot(6,6,s)
    %plot(target_angle,hand_common_bin_angle,'o')
    hold on

    bias=[];
    kk=0;
    hand=handEndAngle;
    for y=361:720
        kk=kk+1;
        f=find(target_angle(:,s)==y);
        %mean.y(y).l=[mean.y(y).l; hand(f)];
        h=hand(f,s);
        h=removeoutlier(h,2.5);
        bias(kk)=nanmean(h);
    end

    plot(x2(1:1:end),bias,'k-')
    plot(x2,y2,'r-')

    y=[y1 y2];

    shand=[];
    for i=1:length(mt)
        ta=target_angle(i,2);
        shand=[shand y(ta)];
    end
    shandall(:,s)=shand;
end

%%
LeftP=[18 22:25];% flip all the left handed

target=target_anglerow;
target(target>360)=target(target>360)-360;

r=target_anglerow>360;
l=target_anglerow<=360;

figure
LeftH=handEndAngle;
LeftH(r)=nan;
RightH=handEndAngle;
RightH(l)=nan;
%
leftb=LeftH;
leftb=removeoutlier(leftb,2.5);
leftV=nanmean(abs(leftb));
rightb=RightH;
rightb=removeoutlier(rightb,2.5);
rightV=nanmean(abs(rightb));
diffv=leftV-rightV;
diffv(LeftP)=nan;

leftb=LeftH-shandall;
leftb=removeoutlier(leftb,3);
leftV=nanstd(leftb);
rightb=RightH-shandall;
rightb=removeoutlier(rightb,3);
rightV=nanstd(rightb);


target_angle=target_anglerow;

for s=[18 22:25]

    ttemp=target_angle(:,s);
    f1=(ttemp>360);
    f2=(ttemp<=360);
    target_angle(f1,s)=ttemp(f1)-360;
    target_angle(f2,s)=ttemp(f2)+360;


end

subplot(2,2,2);hold on
diffv=leftV-rightV;
bar(2,nanmean(diffv(LeftP)));
plotSpread(diffv(LeftP)','categoryIdx',ones(length(LeftP),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',2)


[a,b,c]=ttest(diffv(LeftP));
lineerrorbar('x',2,'y',nanmean(diffv(LeftP)),'std',nanstd(diffv(LeftP))./sqrt(4),'width', 1.5)


diffv(LeftP)=-diffv(LeftP);
[a,b,c,d]=ttest(diffv)

diffv(LeftP)=nan;

bar(1,nanmean(diffv))
plotSpread(diffv','categoryIdx',ones(length(diffv),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)

lineerrorbar('x',1,'y',nanmean(diffv),'std',nanstd(diffv)./sqrt(20),'width', 1.5)
%scatter(1.3,nanmean(diffv),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1,'SizeData',4)


axis([0 3 -1 1])

ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
[a,b,c]=ttest(diffv)


%%
% 2L
%n-1

figure
hand=handEndAngle-shandall;
%hand=removeoutlier(hand,5);

f=find(target_angle>360);
hand(f)=nan;

diffangle_o=target(1:end-1,:)-target(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
diffangle_index=round(diffangle_o/20)+9;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
sdm_v=[];
allt=[];
sdm_v=[];
for subj=1:subnum
    handl2l_temp=[];
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        handl2l_temp=[handl2l_temp; h];
        sdm(subj,y)=nanmean(h);
        sdm_v(subj,y)=nanvar(h);
        if (y<9 && y>4)
            allt=[allt;h];
        elseif(y<13 && y>9)
            allt=[allt;-h];
        end
    end
    handl2l(subj)=nanmean(abs(handl2l_temp));

end

sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm')';
sdm180=(sdm(:,1)+sdm(:,end))/2;
% sdm(:,1)=sdm180;
% sdm(:,end)=sdm180;
% axis([-1 20 -0.5 1.5])
figure(121);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)


co=[0.5 0.8 1];
subplot(2,2,2);hold on
plot([9 9],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2,'FaceColor',co)
plot(nanmean(sdm),'LineWidth',1,'Color',co)
set(gca,'xtick',[1.5:4:20 ]);
axis([0 20 -2.5 2.5])

SDEID=nanmean(sdm(:,6:8),2)-nanmean(sdm(:,10:12),2);
p=[-2,0.01];
f=find(hand>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,diffangle(f),hand(f),[-inf;0],[inf;inf]);

p=beta1;
x=unique(diffangle(f));
plot((x/20)+9,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)

subplot(2,2,4);hold on
SD_LR(:,1)=SDEID;

realboxplot(1,SDEID,[0 0 0],0.3,0.4)
plotSpread(SDEID,'categoryIdx',ones(length(SDEID),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)
lineerrorbar('x',1, 'y', nanmean(SDEID),'std', nanstd(SDEID),'subnum',subnum,'width',1);

scatter(1,nanmean(SDEID),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 6 -2 6])


%%
%n-1 2R

figure
hand=handEndAngle-shandall;
hand=removeoutlier(hand,2.5);

f=find(target_angle<361);
hand(f)=nan;

diffangle_o=target(1:end-1,:)-target(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
diffangle_index=round(diffangle_o/20)+9;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
for subj=1:subnum
    handl2l_temp=[];
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        handl2l_temp=[handl2l_temp; h];
        sdm(subj,y)=nanmean(h);
        if (y<9 && y>4)
            allt=[allt;h];
        elseif(y<13 && y>9)
            allt=[allt;-h];
        end
    end

end

sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm')';
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])
figure(121);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)

co=[0 0 1];

subplot(2,2,2);hold on
plot([9 9],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2,'FaceColor',co)
plot(nanmean(sdm),'LineWidth',1,'color',co)
set(gca,'xtick',[1.5:4:20 ]);
axis([0 20 -2.5 2.5])

p=[-2,0.01];
f=find(hand>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,diffangle(f),hand(f),[-inf;0],[inf;inf]);

p=beta1;
x=unique(diffangle(f));
plot((x/20)+9,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)



SDEID=nanmean(sdm(:,6:8),2)-nanmean(sdm(:,10:12),2);
subplot(2,2,4);hold on
SD_LR(:,2)=SDEID;

realboxplot(2,SDEID,[0 0 0],0.3,0.4)
plotSpread(SDEID,'categoryIdx',ones(length(SDEID),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',2)
lineerrorbar('x',2, 'y', nanmean(SDEID),'std', nanstd(SDEID),'subnum',subnum,'width',1);

scatter(2,nanmean(SDEID),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 6 -2 6])

title('Dom vs Nondom')
%%
%n-1 R2R & L2L 
% same hand
figure
k=[];
LR=Left_right(:,2);
for n=1:numTrials-1
    if (LR(n)==2 && LR(n+1)==2) || (LR(n)==1 && LR(n+1)==1)
        k(n)=0;
    else
        k(n)=1;
    end
end
k=[1 k]';


hand=handEndAngle-shandall;
hand=removeoutlier(hand,2.5);
hand(logical(k),:)=nan;

diffangle_o=target(1:end-1,:)-target(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
diffangle_index=round(diffangle_o/20)+9;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
for subj=1:subnum
    handl2l_temp=[];
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        handl2l_temp=[handl2l_temp; h];
        sdm(subj,y)=nanmean(h);
        if (y<9 && y>4)
            allt=[allt;h];
        elseif(y<13 && y>9)
            allt=[allt;-h];
        end
    end
    handr2r(subj)=nanmean(abs(handl2l_temp));
end

sdm=sdm-nanmean(sdm')';
sdm180=(sdm(:,1)+sdm(:,end))/2;
% sdm(:,1)=sdm180;
% sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])
figure(1221);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)

co=[0 0.4 0];

subplot(2,2,2);hold on
plot([9 9],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2,'FaceColor',co)
plot(nanmean(sdm),'LineWidth',1,'color',co)
set(gca,'xtick',[1.5:4:20 ]);
axis([0 20 -2.5 2.5])

p=[-2,0.01];
f=find(hand>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,diffangle(f),hand(f),[-inf;0],[inf;inf]);

p=beta1;
x=unique(diffangle(f));
plot((x/20)+9,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)


SDEID=nanmean(sdm(:,6:8),2)-nanmean(sdm(:,10:12),2);
subplot(2,2,4);hold on
SDLR(:,4)=SDEID;
realboxplot(2,SDEID,[0 0 0],0.3,0.4)
plotSpread(SDEID,'categoryIdx',ones(length(SDEID),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',2)
lineerrorbar('x',2, 'y', nanmean(SDEID),'std', nanstd(SDEID),'subnum',subnum,'width',1);

scatter(2,nanmean(SDEID),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 6 -2 6])


%% cross hand
%n-1 R2L or L2R
figure
k=[];
LR=Left_right(:,2);
for n=1:numTrials-1
    if (LR(n)==2 && LR(n+1)==1) || (LR(n)==1 && LR(n+1)==2)
        k(n)=0;
    else
        k(n)=1;
    end
end
k=[1 k]';


hand=handEndAngle-shandall;
hand=removeoutlier(hand,2.5);
hand(logical(k),:)=nan;

diffangle_o=hand_angle(1:end-1,:)-hand_angle(2:end,:);
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=(diffangle_o);
diffangle_index=round(diffangle_o/20)+9;
m=max(max(diffangle_index));

s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

sdm=[];
for subj=1:subnum
    handl2l_temp=[];
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        handl2l_temp=[handl2l_temp; h];
        sdm(subj,y)=nanmean(h);
        if (y<9 && y>4)
            allt=[allt;h];
        elseif(y<13 && y>9)
            allt=[allt;-h];
        end
    end
    handr2l(subj)=nanmean(abs(handl2l_temp));
end

sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm')';
sdm180=(sdm(:,1)+sdm(:,end))/2;
% sdm(:,1)=sdm180;
% sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])
figure(1221);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)

co=[0.5 0.8 0.5];

subplot(2,2,2);hold on
plot([9 9],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],[1 0.5 0.5],'EdgeColor','none','FaceAlpha',0.2,'FaceColor',co)
plot(nanmean(sdm),'LineWidth',1,'color',co)
set(gca,'xtick',[1.5:4:20 ]);
axis([0 20 -2.5 2.5])

p=[-2,0.01];
f=find(hand>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,diffangle(f),hand(f),[-inf;0],[inf;inf]);

p=beta1;
x=unique(diffangle(f));
plot((x/20)+9,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)


SDEID=nanmean(sdm(:,6:8),2)-nanmean(sdm(:,10:12),2);
subplot(2,2,4);hold on
SDLR(:,4)=SDEID;
realboxplot(1,SDEID,[0 0 0],0.3,0.4)
plotSpread(SDEID,'categoryIdx',ones(length(SDEID),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)
lineerrorbar('x',1, 'y', nanmean(SDEID),'std', nanstd(SDEID),'subnum',subnum,'width',1);

scatter(1,nanmean(SDEID),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 6 -2 6])


title('same vs different')

%%
% same vs different
[a,b,c,d]=ttest(SDLR(:,4)-SDLR(:,2));

% left vs right
[a,b,c,d]=ttest(SD_LR(:,1)-SD_LR(:,2));
