% 
clear; close all; 
load('Exp4')

%% correct for systematic bias
hand=hand_common_bin_angle;

% find Go-Opposite trials
catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end,:)=[];

% find Go-Target trials
notcatch=(catcht~=4);
hand(logical(1-catt))=nan;

hand(abs(hand)<90)=nan;
hand0=hand;
hand(hand0<0)=180+hand(hand0<0);
hand(hand0>0)=-180+hand(hand0>0);


f=find(hand>-1000);
p = polyfit(target_angle(f),hand(f),10);

x1 = 0:1:360;
y1 = polyval(p,x1);
% figure
% subplot(2,2,1)
% %plot(target_angle,hand_common_bin_angle,'o')
% hold on

bias=[];
kk=0;
for y=0:2:360
    kk=kk+1;
    f=find(target_angle==y);
    %mean.y(y).l=[mean.y(y).l; hand(f)];
    h=hand(f);
    h=removeoutlier(h,2.5);
    bias(kk)=nanmean(h);
end

% plot(0:2:360,bias,'k.')
% 
% plot(x1,y1,'r-','LineWidth',3)
% 
% axis([0 360 -4 4])
% ax = gca;
% ax.YAxis.TickDirection = 'out';
% ax.XAxis.TickDirection = 'out';


shand=[];
for i=1:length(mt_bin(:))
    ta=target_angle(i);
    shand=[shand y1(ta+1)];
end

shand_c=reshape(shand,trial_num,subnum);

hand=hand_common_bin_angle;
catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end,:)=[];
notcatch=(catcht~=4);
hand(logical(catt))=nan;

hand(abs(hand)>90)=nan;


f=find(hand>-1000);
p = polyfit(target_angle(f),hand(f),10);

x1 = 0:1:360;
y1 = polyval(p,x1);
% figure
% subplot(2,2,1)
% %plot(target_angle,hand_common_bin_angle,'o')
% hold on

bias=[];
kk=0;
for y=0:2:360
    kk=kk+1;
    f=find(target_angle==y);
    %mean.y(y).l=[mean.y(y).l; hand(f)];
    h=hand(f);
    h=removeoutlier(h,2.5);
    bias(kk)=nanmean(h);
end

% plot(0:2:360,bias,'k.')
% 
% plot(x1,y1,'r-','LineWidth',3)
% 
% axis([0 360 -4 4])
% ax = gca;
% ax.YAxis.TickDirection = 'out';
% ax.XAxis.TickDirection = 'out';


shand=[];
for i=1:length(mt_bin(:))
    ta=target_angle(i);
    shand=[shand y1(ta+1)];
end

shand_nc=reshape(shand,trial_num,subnum);


hand=hand_common_bin_angle;
catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end,:)=[];
notcatch=(catcht~=4);
hand(logical(catt))=nan;

hand(abs(hand)>90)=nan;

figure
for s=1:subnum

    subplot(10,6,s)
    hold on

    bias=[];
    kk=0;
    for y=0:2:360
        kk=kk+1;
        f=find(target_angle(:,s)==y);
        h=hand(f,s);
        h=removeoutlier(h,2.5);
        bias(kk)=nanmean(h);
    end


    f=find(bias>-1000);
    y=[0:2:360];
    p = polyfit(y(f),bias(f),20);
    x1 = 0:1:360;
    y1 = polyval(p,x1);
    plot(0:2:360,bias,'k.')
    plot(x1,y1,'r-','LineWidth',3)


    shand=[];
    for i=1:length(mt_bin)
        ta=target_angle(i,s);
        shand=[shand y1(ta+1)];
    end

    shandall(:,s)=shand;
end


%%
%opposite trial 
% n-1 var 
% hand diff

catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end-1:end,:)=[];
notcatch=(catcht~=4);
notcatch=[ones(1,subnum);notcatch];
notcatch(end-1:end,:)=[];
hand=hand_common_bin_angle-shandall;

catc=(catcht==4);
catc=[ones(1,subnum);catc];
catc(end,:)=[];
hand_cat=hand;
hand_cat(logical(1-catc))=nan;
f=find(abs(hand_cat)<90);
hand_angle(f)=nan;

hand(1:35,:)=nan;
hand(abs(hand)>40)=nan;
hand=removeoutlier(hand,3);



diffangle_o=hand_angle(1:end-1,:)-hand_angle(2:end,:);
diffangle_o(logical(notcatch))=nan;
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=abs(diffangle_o);
diffangle_index=ceil(diffangle/30);
m=max(max(diffangle_index));
sd=[];
s=sign(diffangle_o);

hand=s.*hand(2:end,:);
sdm=[];
sdm_v=[];
allt=[];
for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

for subj=1:subnum
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        sdm(subj,y)=nanmean(h);
        sdm_v(subj,y)=nanstd(h);

    end
end
sdm=removeoutlier(sdm,2.5);
sdm_v(:,end)=[];
sdm_v=removeoutlier(sdm_v,3);
sdm_v=sdm_v./nanmean(sdm_v')';
sdm_v(sdm_v<0.001)=nan;



figure(3234);
subplot(2,3,1);hold on

se=[nanstd(sdm_v)./sqrt(subnum)];
averag=nanmean(sdm_v)';
for i=1:size(sdm_v,2)
    lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
    scatter(i,averag(i),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',60)
end
axis([0 6 0.92 1.07])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';

y=sdm_v';
fi=fitlm(repmat(1:5,1,subnum)',y(:));



ft = fittype('a + (b-a) / (1 + exp(-c * (x)))', ...
    'independent', 'x', ...
    'coefficients', {'a', 'b', 'c'});
initial_params = [1, 1, 1];
y=sdm_v';
x=repmat(1:5,1,subnum)';
y=y(:);
% Bootstrap resampling
num_bootstrap_samples = 100;%1000
bootstrap_ab = zeros(num_bootstrap_samples, 1);
rng(0); % For reproducibility

for i = 1:num_bootstrap_samples
    % Resample the data with replacement
    idx = randi(length(x), length(x), true);
    x_resample = x(idx);
    y_resample = y(idx);

    % Fit the model to the resampled data
    [fitresult, ~] = fit(x_resample(y_resample>0), y_resample(y_resample>0), ft, 'StartPoint', initial_params);

    % Compute the product a * b for the resampled fit
    bootstrap_ab(i) = (fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));
end

% subplot(2,2,2);hold on
% %bar(backs,nanmean(bootstrap_ab));
% alpha = 0.05; % 95% confidence interval
% bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
% bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
% ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
% %lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',ci_ab(2)-ci_ab(1),'width', 1.5)
% realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)

subplot(2,2,3);hold on
bar(1,nanmean(bootstrap_ab));
%alpha = 0.05; % 95% confidence interval
%ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
lineerrorbar('x',1,'y',nanmean(bootstrap_ab),'std',nanstd(bootstrap_ab),'width', 1.5)
%realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)

axis([-1 6 -0.03 0.09])


%%
%opposite trial
% n-1 var 
% target diff

catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end-1:end,:)=[];
notcatch=(catcht~=4);
notcatch=[ones(1,subnum);notcatch];
notcatch(end-1:end,:)=[];
hand=hand_common_bin_angle-shandall;
hand(1:35,:)=nan;
hand(abs(hand)>40)=nan;
hand=removeoutlier(hand,2.5);


diffangle_o=target_angle(1:end-1,:)-target_angle(2:end,:);
diffangle_o(logical(notcatch))=nan;

f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);

diffangle=abs(diffangle_o);
diffangle_index=ceil(diffangle/30);
m=max(max(diffangle_index));
sd=[];
s=sign(diffangle_o);

hand=s.*hand(2:end,:);
sdm=[];
sdm_v=[];
allt=[];
for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end

for subj=1:subnum
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        %h=removeoutlier(h,3);
        sdm(subj,y)=nanmean(h);
        sdm_v(subj,y)=nanstd(h);

    end
end
sdm=removeoutlier(sdm,2.5);
sdm_v(:,end)=[];
sdm_v=removeoutlier(sdm_v,3);
sdm_v=sdm_v./nanmean(sdm_v')';
sdm_v(sdm_v<0.001)=nan;



figure(323);
subplot(2,3,1);hold on

se=[nanstd(sdm_v)./sqrt(subnum)];
averag=nanmean(sdm_v)';
for i=1:size(sdm_v,2)
    lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
    scatter(i,averag(i),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',60)
end
axis([0 6 0.92 1.07])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
y=sdm_v';
fi=fitlm(repmat(1:5,1,subnum)',y(:));


ft = fittype('a + (b-a) / (1 + exp(-c * (x)))', ...
    'independent', 'x', ...
    'coefficients', {'a', 'b', 'c'});
initial_params = [1, 1, 1];
y=sdm_v';
x=repmat(1:5,1,subnum)';
y=y(:);
% Bootstrap resampling
num_bootstrap_samples = 100;
bootstrap_ab = zeros(num_bootstrap_samples, 1);
rng(0); % For reproducibility

for i = 1:num_bootstrap_samples
    % Resample the data with replacement
    idx = randi(length(x), length(x), true);
    x_resample = x(idx);
    y_resample = y(idx);

    % Fit the model to the resampled data
    [fitresult, ~] = fit(x_resample(y_resample>0), y_resample(y_resample>0), ft, 'StartPoint', initial_params);

    % Compute the product a * b for the resampled fit
    bootstrap_ab(i) = (fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));
end

% subplot(2,2,2);hold on
% %bar(backs,nanmean(bootstrap_ab));
% alpha = 0.05; % 95% confidence interval
% bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
% bootstrap_ab=removeoutlier(bootstrap_ab,2.5);
% ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
% %lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',ci_ab(2)-ci_ab(1),'width', 1.5)
% realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)

subplot(2,2,3);hold on
bar(1,nanmean(bootstrap_ab));
%alpha = 0.05; % 95% confidence interval
%ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
lineerrorbar('x',1,'y',nanmean(bootstrap_ab),'std',nanstd(bootstrap_ab),'width', 1.5)
%realboxplot(1,bootstrap_ab',[0 0 0],0.3,0.4)

axis([-1 6 -0.03 0.09])

%%
% opposite trial 
% n-1 bias 
% hand diff

notcatch=(catcht~=4);
notcatch=[ones(1,subnum);notcatch];
notcatch(end-1:end,:)=[];
hand=hand_common_bin_angle;

catc=(catcht==4);
catc=[ones(1,subnum);catc];
catc(end,:)=[];
hand_angle_cat=hand_angle;
hand_cat=hand;
hand_cat(logical(1-catc))=nan;
f=find(abs(hand_cat)<90);
hand_angle(f)=nan;


hand(1:35,:)=nan;
hand(abs(hand)>60)=nan;
hand=removeoutlier(hand,2.5);

diffangle_o=hand_angle(1:end-1,:)-hand_angle(2:end,:);
diffangle_o(logical(notcatch))=nan;
diffangle_o(1:40,:)=nan;

f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);


diffangle=abs(diffangle_o);

unique(diffangle(diffangle>-1000))
diffangle_index=round(diffangle_o/30)+7;
m=max(max(diffangle_index));

% s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end
sdm=[];
for subj=1:subnum
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        sdm(subj,y)=nanmedian(h);
    end
end

sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm,2);
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])
figure(111);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)

dif=nanmean(sdm(:,4:6),2)-nanmean(sdm(:,8:11),2);
difO=dif;
subplot(2,2,3);hold on

realboxplot(1,dif,[0 0 0],0.3,0.4)
plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)
lineerrorbar('x',1, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);

scatter(1,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 7 -3.5 5.5])

%axis([0 7 0 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
[a b c d]=ttest(dif)
dif1=dif;


co=[0.5 0 1];

subplot(2,2,2);hold on
plot([7 7],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
plot(nanmean(sdm),'LineWidth',1,'color',co)
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';


set(gca,'xtick',[1:3:20]);
axis([0 14 -2.5 2.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
%set(gca, 'LineWidth',1);


p=[3,0.1];
f=find(diffangle_o>-10000);
x=diffangle_o(f);
y=hand(f);
f=find(y>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,-6:6,nanmean(sdm),[-inf;0],[inf;inf]);


subplot(2,2,2); hold on
p=beta1;
x=-6:0.1:6;
plot(x+7,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)



%%
% opposite trial 
% n-1 bias 
% target diff

catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end-1:end,:)=[];
notcatch=(catcht~=4);
notcatch=[ones(1,subnum);notcatch];
notcatch(end-1:end,:)=[];
hand=hand_common_bin_angle;

hand(1:35,:)=nan;
hand(abs(hand)>60)=nan;
hand=removeoutlier(hand,2.5);

diffangle_o=target_angle(1:end-1,:)-target_angle(2:end,:);
diffangle_o(logical(notcatch))=nan;
diffangle_o(1:40,:)=nan;

f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);
diffangle=abs(diffangle_o);

unique(diffangle(diffangle>-1000))
diffangle_index=round(diffangle_o/30)+7;
m=max(max(diffangle_index));

% s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end
sdm=[];
for subj=1:subnum
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        sdm(subj,y)=nanmedian(h);
    end
end
sdm=removeoutlier(sdm,2.5);

sdm=sdm-nanmean(sdm(:));
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 20 -0.5 1.5])
figure(112);
subplot(2,2,1);hold on
plot(sdm')
plot(nanmean(sdm),'LineWidth',5)

dif=nanmean(sdm(:,3:6),2)-nanmean(sdm(:,8:11),2);
subplot(2,2,3);hold on
realboxplot(1,dif,[0 0 0],0.3,0.4)
plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)
lineerrorbar('x',1, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);

scatter(1,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 7 -3.5 5.5])

ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
[a b c d]=ttest(dif)


co=[0.9 0.7 0];

subplot(2,2,2);hold on
plot([7 7],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
plot(nanmean(sdm),'LineWidth',1,'color',co)

ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';


set(gca,'xtick',[1:3:20]);
axis([0 14 -2.5 2.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
%set(gca, 'LineWidth',1);


p=[3,0.1];
f=find(diffangle_o>-10000);
x=diffangle_o(f);
y=hand(f);
f=find(y>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,-6:6,nanmean(sdm),[-inf;0],[inf;inf]);


subplot(2,2,2); hold on
p=beta1;
x=-6:0.1:6;
plot(x+7,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)
[a b c d]=ttest2(dif,dif1)
axis([0 14 -2 2])

%%
% Normal trial 
% n-1 bias 


catt=(catcht==4);
catt=[ones(1,subnum);catt];
catt(end-1:end,:)=[];
notcatch=(catcht~=4);
notcatch=[ones(1,subnum);notcatch];
notcatch(end-1:end,:)=[];
hand=hand_common_bin_angle;

hand(1:35,:)=nan;
hand(abs(hand)>30)=nan;
hand=removeoutlier(hand,2.5);

diffangle_o=target_angle(1:end-1,:)-target_angle(2:end,:);
diffangle_o(logical(catt))=nan;
diffangle_o(1:40,:)=nan;
f=find((diffangle_o)>180);
diffangle_o(f)=(diffangle_o(f)-360);
f=find((diffangle_o)<-180);
diffangle_o(f)=(diffangle_o(f)+360);
diffangle=abs(diffangle_o);

unique(diffangle(diffangle>-1000))
diffangle_index=round(diffangle_o/30)+7;
m=max(max(diffangle_index));

% s=sign(diffangle_o);
hand=hand(2:end,:);

for subj=1:subnum
    for y=1:m
        sd(subj).y(y).l=[0];
    end
end
sdm=[];
for subj=1:subnum
    for y=1:m
        f=find(diffangle_index(:,subj)==y);
        sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
        h=hand(f,subj);
        h=removeoutlier(h,2.5);
        sdm(subj,y)=nanmedian(h);
    end
end
sdm=removeoutlier(sdm,2.5);
sdm=sdm-nanmean(sdm(:));
sdm180=(sdm(:,1)+sdm(:,end))/2;
sdm(:,1)=sdm180;
sdm(:,end)=sdm180;
axis([-1 6 -0.5 1.5])
figure(113);


dif=nanmean(sdm(:,5:6),2)-nanmean(sdm(:,8:9),2);
subplot(2,2,3);hold on
% bar(nanmean(dif));
% lineerrorbar('x',1, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',3);

realboxplot(1,dif,[0 0 0],0.3,0.4)
plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',1)
lineerrorbar('x',1, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);

scatter(1,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20)

set(gca,'xtick',[]);
axis([0 7 -3.5 5.5])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
[a b c d]=ttest(dif);

%fun = @(p,x)p(1).*p(2).*sind(x).*exp(p(2).*cosd(x));


co=[1 0 0];

subplot(2,2,2);hold on
plot([7 7],[-100 100],'k--')
plot([-100 100],[0 0],'k--')
se=[nanstd(sdm)./sqrt(subnum)];
averag=nanmean(sdm)';
fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
plot(nanmean(sdm),'LineWidth',1,'color',co)
% for i=1:length(se)
%     lineerrorbar('x',i, 'y', nanmean(sdm(:,i)),'std', nanstd(sdm(:,i)),'subnum',length(sdm(:,i)),'width',1,'color',co);
%     scatter(i, nanmean(sdm(:,i)),20,'markerfacecolor',co,'markerfacealpha',1,'markeredgecolor','k','linewidth',1)
% end
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';


set(gca,'xtick',[1:3:20]);
axis([0 14 -2 2])
ax = gca;
ax.YAxis.TickDirection = 'out';
ax.XAxis.TickDirection = 'out';
%set(gca, 'LineWidth',1);


p=[3,0.1];
f=find(diffangle_o>-10000);
x=diffangle_o(f);
y=hand(f);
f=find(y>-10000);
cc=sqrt(2)/exp(-0.5);
fun = @(p,x)p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2) ;
beta1 = lsqcurvefit(fun,p,-6:6,nanmean(sdm),[-inf;0],[inf;inf]);


subplot(2,2,2); hold on
p=beta1;
x=-6:0.1:6;
plot(x+7,p(1).*p(2).*cc.*x.*exp(-(p(2).*x).^2),'-','LineWidth',3,'color',co)
motor_var=nanstd(hand);


subplot(2,2,4);hold on
err=motor_var;
x=err(err>0);
y=dif(err>0);
f=y>0;
scatter(x(f),y(f),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
coefficients = polyfit(x(f)',y(f), 1);
fittedY = polyval(coefficients, x(f));
plot(x(f),fittedY)
[a,b]=corr(y(f),x(f)');
axis([3.1 8.9 -1.5 4.9])
%

[a,b,c,d]=ttest(dif-difO);

