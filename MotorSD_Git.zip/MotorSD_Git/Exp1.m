

save('Exp1','target_angle','hand_angle','subnum',"rt_bin",'mt_bin','hand_common_bin_angle','rotation')

%%
clear; close all; 
load('Exp1')
% control for systematic bias

shandall=[];
figure
for  s=1:subnum
    hand=hand_common_bin_angle(:,s);
    f=find(hand>-1000);
    p = polyfit(target_angle(f,s),hand(f),10);
    x1 = 1:1:360;
    y1 = polyval(p,x1);

    subplot(5,7,s)
    hold on


    kk=0;
    for y=1:360
        kk=kk+1;
        f=find(target_angle(:,s)==y);
        h=hand(f);
        h=removeoutlier(h,2.5);
        bias(kk)=nanmean(h);
    end

    plot(1:360,bias,'k.')

    plot(x1,y1,'r-','LineWidth',3)

    %axis([0 360 -8 8])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';


    shand=[];
    for i=1:length(mt_bin)
        ta=target_angle(i,s);
        if ta>360
            ta=ta-360;
        end
        shand=[shand y1(ta)];
    end

    shandall(:,s)=shand;
end


%% sequential effect in motor variance
%n-1
for backs=1 % -1: n+1;  1: n-1; 2: n-2 ...

    hand=hand_common_bin_angle-shandall;
    f=find(abs(hand)>40);
    hand_angle(f)=NaN;
    hand=removeoutlier(hand,3);


    diffangle_o=hand_angle(3:end-backs-2,:)-hand_angle(backs+1+2:end-2,:);
    f=find((diffangle_o)>180);
    diffangle_o(f)=(diffangle_o(f)-360);
    f=find((diffangle_o)<-180);
    diffangle_o(f)=(diffangle_o(f)+360);

    diffangle=abs(diffangle_o);
    diffangle_index=ceil(diffangle/30);
    m=max(max(diffangle_index));
    sd=[];
    s=sign(diffangle_o);
    hand=s.*hand(backs+1+2:end-2,:);
    sdm=[];
    sdm_v=[];
    allt=[];
    for subj=1:subnum
        for y=1:m
            sd(subj).y(y).l=[0];
        end
    end

    for subj=1:subnum
        for y=1:m
            f=find(diffangle_index(:,subj)==y);
            sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
            h=hand(f,subj);
            %h=removeoutlier(h,3);
            sdm(subj,y)=nanmean(h);
            sdm_v(subj,y)=nanstd(h);
        end

    end

    sdm_v(:,end)=[];
    sdm_v=sdm_v./nanmean(sdm_v')';
    sdm_v(sdm_v<0.001)=nan;

    figure(344)
    subplot(2,3,1);hold on
    se=[nanstd(sdm_v)./sqrt(subnum)];
    averag=nanmean(sdm_v)';
    for i=1:size(sdm_v,2)
        lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
        scatter(i,averag(i),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',60)
    end
    axis([0 6 0.92 1.07])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';

       figure(344)
    subplot(2,3,4);hold on
    se=[nanstd(sdm_v)./sqrt(subnum)];
    averag=nanmean(sdm_v)';
    plot( averag)
    for i=1:size(sdm_v,2)
        lineerrorbar('x',i,'y',averag(i),'std',se(i),'width', 1.5)
    end
    axis([0 6 0.92 1.07])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';



    for s=1:subnum

        l(s)=corr([1:5]',sdm_v(s,:)');
        % Initial guesses for the parameters [a, b, c, d]
        initial_params = [1, 1, 1];

        % Create a fit type object
        ft = fittype('a + (b-a) / (1 + exp(-c * (x)))', ...
            'independent', 'x', ...
            'coefficients', {'a', 'b', 'c'});
        % Fit the data
        [fitresult, gof] = fit([1:5]', sdm_v(s,:)', ft, 'StartPoint', initial_params);
        l(s)=(fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));

    end
    y=sdm_v';
    x=repmat(1:5,1,subnum)';
    y=y(:);


    % Bootstrap resampling
    num_bootstrap_samples = 100;%% 1000

    bootstrap_ab = zeros(num_bootstrap_samples, 1);
    rng(0); % For reproducibility

    for i = 1:num_bootstrap_samples
        % Resample the data with replacement
        idx = randi(length(x), length(x), true);
        x_resample = x(idx);
        y_resample = y(idx);

        % Fit the model to the resampled data
        [fitresult, ~] = fit(x_resample, y_resample, ft, 'StartPoint', initial_params);
        bootstrap_ab(i) = (fitresult.b-fitresult.a)./(1+exp(-5*fitresult.c))-(fitresult.b-fitresult.a)./(1+exp(-fitresult.c));
    end


    if backs==-1
        backs=0;
    end
    subplot(2,2,2);hold on
    bar(backs,nanmean(bootstrap_ab));
    alpha = 0.05; % 95% confidence interval
    ci_ab = prctile(bootstrap_ab, [100*alpha/2, 100*(1-alpha/2)]);
    lineerrorbar('x',backs,'y',nanmean(bootstrap_ab),'std',nanstd(bootstrap_ab),'width', 1.5)
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';
    axis([-1 6 -0.03 0.09])

end


%% sequential effect in motor Bias n-1:n-5

%n-back
for backs=1:5

    hand=hand_common_bin_angle-shandall;
    hand=removeoutlier(hand,2.5);

    diffangle_o=target_angle(1:end-backs,:)-target_angle(backs+1:end,:);
    f=find((diffangle_o)>180);
    diffangle_o(f)=(diffangle_o(f)-360);
    f=find((diffangle_o)<-180);
    diffangle_o(f)=(diffangle_o(f)+360);

    diffangle=(diffangle_o);
    diffangle_index=round(diffangle/30)+7;
    m=max(max(diffangle_index));

    s=sign(diffangle_o);
    hand=hand(backs+1:end,:);

    for subj=1:subnum
        for y=1:m
            sd(subj).y(y).l=[0];
        end
    end

    sdm=[];
    for subj=1:subnum
        for y=1:m
            f=find(diffangle_index(:,subj)==y);
            sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
            h=hand(f,subj);
            h=removeoutlier(h,2.5);
            sdm(subj,y)=nanmean(h);
        end
    end

    sdm=sdm-nanmean(sdm(:));
    sdm180=(sdm(:,1)+sdm(:,end))/2;
    sdm(:,1)=sdm180;
    sdm(:,end)=sdm180;
    figure(1232)
    co=[0.7 0 0];
    subplot(2,2,2);hold on
    plot([7 7],[-100 100],'k--')
    plot([-100 100],[0 0],'k--')
    se=[nanstd(sdm)./sqrt(subnum)];
    averag=nanmean(sdm)';
    fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
    plot(nanmean(sdm),'LineWidth',1,'color',co)


    set(gca,'xtick',[1:3:20]);
    axis([0 14 -2.5 2.5])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';



    dif=nanmean(sdm(:,5:6),2)-nanmean(sdm(:,8:9),2);
    dif=removeoutlier(dif,2.5);



    subplot(2,2,3);hold on
    realboxplot(backs,dif,[0 0 0],0.3,0.4);
    plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',backs);
    lineerrorbar('x',backs, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);
    scatter(backs,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20);

    set(gca,'xtick',[]);
    axis([-1 6 -1.5 4.9])

    if backs==1
        subplot(2,2,4);hold on
        err=nanstd(hand);
        scatter(err(err>0),dif(err>0),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',0.3,'SizeData',20)
        coefficients = polyfit(err(err>0)',dif(err>0), 1);
        fittedY = polyval(coefficients, err(err>0));
        plot(err(err>0),fittedY)
        [a,b]=corr(dif(err>0),err(err>0)')

        axis([3.1 8.1 -1.5 4.9])
        ax = gca;
        ax.YAxis.TickDirection = 'out';
        ax.XAxis.TickDirection = 'out';

       
    end

     [a b c d]=ttest(dif)
end

%%
%1-future
for backs=0
    hand=hand_common_bin_angle-shandall;
    hand=removeoutlier(hand,2.5);

    diffangle_o=target_angle(3:end,:)-target_angle(2:end-1,:);
    f=find((diffangle_o)>180);
    diffangle_o(f)=(diffangle_o(f)-360);
    f=find((diffangle_o)<-180);
    diffangle_o(f)=(diffangle_o(f)+360);

    diffangle=(diffangle_o);
    diffangle_index=round(diffangle/30)+7;
    m=max(max(diffangle_index));

    s=sign(diffangle_o);
    hand=hand(2:end,:);

    for subj=1:subnum
        for y=1:m
            sd(subj).y(y).l=[0];
        end
    end

    sdm=[];
    for subj=1:subnum
        for y=1:m
            f=find(diffangle_index(:,subj)==y);
            sd(subj).y(y).l=[sd(subj).y(y).l; hand(f,subj)];
            h=hand(f,subj);
            h=removeoutlier(h,2.5);
            sdm(subj,y)=nanmean(h);
        end
    end

    sdm=sdm-nanmean(sdm(:));
    sdm180=(sdm(:,1)+sdm(:,end))/2;
    sdm(:,1)=sdm180;
    sdm(:,end)=sdm180;
    figure(1232)
    co=[0.7 0 0];
    subplot(2,2,2);hold on
    plot([7 7],[-100 100],'k--')
    plot([-100 100],[0 0],'k--')
    se=[nanstd(sdm)./sqrt(subnum)];
    averag=nanmean(sdm)';
    fill([1:length(se) length(se):-1:1],[averag'+se averag(end:-1:1)'-se(end:-1:1)],co,'EdgeColor','none','FaceAlpha',0.2)
    plot(nanmean(sdm),'LineWidth',1,'color',co)


    set(gca,'xtick',[1:3:20]);
    axis([0 14 -2.5 2.5])
    ax = gca;
    ax.YAxis.TickDirection = 'out';
    ax.XAxis.TickDirection = 'out';



    dif=nanmean(sdm(:,5:6),2)-nanmean(sdm(:,8:9),2);
    dif=removeoutlier(dif,2.5);



    subplot(2,2,3);hold on
    realboxplot(backs,dif,[0 0 0],0.3,0.4);
    plotSpread(dif,'categoryIdx',ones(length(dif),1),'distributionMarkers',{'o'},'distributioncolor',{num2str([0.5 0.5 0.5])},'xValues',backs);
    lineerrorbar('x',backs, 'y', nanmean(dif),'std', nanstd(dif),'subnum',subnum,'width',1);
    scatter(backs,nanmean(dif),'MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0.8 .8 .8], 'LineWidth',1.5,'SizeData',20);

    set(gca,'xtick',[]);
    axis([-1 6 -1.5 4.9])

    ttest(dif)

end
